import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ─── BFS ─────────────────────────────────────────────────────────────────────

interface PathNode {
  PathID: number;
  Start: number;
  End: number;
  PSequenceID: number;
  StatusID: number;
  AccessToggle: number;
}

function bfs(startId: number, endId: number, paths: PathNode[]): PathNode[] | null {
  if (startId === endId) return [];

  const adj = new Map<number, PathNode[]>();
  for (const p of paths) {
    if (!adj.has(p.Start)) adj.set(p.Start, []);
    adj.get(p.Start)!.push(p);
  }

  const visited = new Set<number>([startId]);
  const queue: Array<{ node: number; route: PathNode[] }> = [
    { node: startId, route: [] },
  ];

  while (queue.length > 0) {
    const { node, route } = queue.shift()!;
    for (const path of adj.get(node) ?? []) {
      if (!visited.has(path.End)) {
        const newRoute = [...route, path];
        if (path.End === endId) return newRoute;
        visited.add(path.End);
        queue.push({ node: path.End, route: newRoute });
      }
    }
  }
  return null;
}

// ─── GET /api/bfs?entrance=<name>&destination=<name> ─────────────────────────

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const entrance    = (searchParams.get("entrance") ?? "").trim();
  const destination = (searchParams.get("destination") ?? "").trim();

  if (!entrance || !destination) {
    return NextResponse.json(
      { error: "Missing entrance or destination query params" },
      { status: 400 }
    );
  }

  try {
    // Resolve names → IDs
    const [startDest, endDest] = await Promise.all([
      prisma.destination.findFirst({ where: { DestinationName: entrance }, select: { DestinationID: true, DestinationName: true } }),
      prisma.destination.findFirst({ where: { DestinationName: destination }, select: { DestinationID: true, DestinationName: true } }),
    ]);

    if (!startDest) {
      return NextResponse.json({ error: `Entrance not found: "${entrance}"` }, { status: 404 });
    }
    if (!endDest) {
      return NextResponse.json({ error: `Destination not found: "${destination}"` }, { status: 404 });
    }

    if (startDest.DestinationID === endDest.DestinationID) {
      return NextResponse.json({ legs: [], message: "Already there!" });
    }

    // Load all active paths for BFS
    const allPaths = await prisma.path.findMany({
      where: { Status: { StatusType: "Active" } },
      select: {
        PathID: true,
        PathName: true,
        Start: true,
        End: true,
        PSequenceID: true,
        StatusID: true,
        AccessToggle: true,
        BuildingID: true,
        Destination_Path_StartToDestination: { select: { DestinationName: true } },
        Destination_Path_EndToDestination:   { select: { DestinationName: true } },
      },
    });

    // BFS
    const route = bfs(startDest.DestinationID, endDest.DestinationID, allPaths);

    if (route === null) {
      return NextResponse.json(
        { error: "No route found between these locations" },
        { status: 404 }
      );
    }

    // Build leg summary (media fetched client-side per leg via /api/paths/[id]/sequence)
    const legs = route.map((p) => ({
      pathId:    p.PathID,
      pathName:  (p as any).PathName,
      start:     p.Start,
      end:       p.End,
      startName: (p as any).Destination_Path_StartToDestination?.DestinationName ?? null,
      endName:   (p as any).Destination_Path_EndToDestination?.DestinationName   ?? null,
    }));

    return NextResponse.json({
      entrance,
      destination,
      totalLegs: legs.length,
      legs,
    });
  } catch (err: any) {
    console.error("GET /api/bfs error:", err);
    return NextResponse.json(
      { error: "Internal server error", details: err?.message },
      { status: 500 }
    );
  }
}
